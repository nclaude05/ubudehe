package com.ubudeheSystem.Ubudehe.App.Services.Impl;

public class IUserService {
    
}
